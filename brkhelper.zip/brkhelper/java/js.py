from linepy3 import *
from justgood import imjustgood
from BEAPI import BEAPI
from Liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from datetime import timedelta, date
from datetime import datetime
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from time import sleep
from bs4 import BeautifulSoup as bSoup
from bs4 import BeautifulSoup
import calculators
from calculators.apself import ApCalculator
from humanfriendly import format_timespan, format_size, format_number, format_length
from Naked.toolshed.shell import execute_js
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from random import randint
from shutil import copyfile
import youtube_dl
from youtube_dl import YoutubeDL
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import platform
import requests, json
import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=========================================================
f = open('token1.txt','r')
token = f.read()

cl = LINE("{}".format(str(token)))
f.close()
#cl = LINE("sanova3@region13.tk","jakarta11")
cl.log("Auth Token : " + str(cl.authToken))
cl.log("Timeline Token : " + str(cl.tl.channelAccessToken))
#=========================================================
oepoll = OEPoll(cl)
#=========================================================
#=========================================================
clProfile = cl.getProfile()
clSettings = cl.getSettings()
#=========================================================
clMID = cl.profile.mid
mid = cl.profile.mid
creator = ["u35aa06efe8cfc198633554199261cc60"]
owner = ["u35aa06efe8cfc198633554199261cc60"]
admin = [clMID]
staff = [clMID]
KAC = [cl]
ABC = [cl]
Bots = [mid]
Alvian = creator + owner+ admin + staff
#=========================================================
protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
welcome = []
leave = []
msg_dict = {}
msg_dict1 = {}
#=========================================================
settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "changeCover":{},
    "autoJoinTicket":False,
    "readerPesan": "Gw @!, Kang Sider",
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

tailah = {
    "siderTemp": {},
    "siderPesan": "You can join chat?",
}

read = { 
    "readMember": {},
    "readPoint": {}
}

tes = {
    "Message": {},
    "msg": {},
}

tes2 = {
    "Message2": {},
    "msg2": {},
}

wait = {
    "Limit": 50,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":False,
    "tiktok":True,
    "contact":False,
    'autoBlock':False,
    'autoJoin':True,
    'autoAdd':True,
    'autotext':False,
    'autoLeave':False,
    'Timeline':False,
    "detectMention":False,
    "Mentionkick":False,
    "welcomeOn":False,
    "stickerOn":False,
    "sticker":False,
    "smule": False,
    "changevp": False,
    "changeFoto": {},
    "likeOn": False,
    "stickers": {},
    "salam" : "وَعَلَيْكُمْ السَّلاَمُ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ",
    "apikey" : "dedeuned",
    "call" : False,
    "callText": "Maaf kak belum bisa naik",
    "apkTikel": False,
    "AddstickerSider": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "AddstickerTag": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "AddstickerPesan": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "AddstickerWelcome": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "AddstickerLeave": {
        "sid": "",
        "spkg": "",
        "status": False
    },
    "stk":{},
    "selfbot":True,
    "token":False,
    "yt":False,
    "responGc":False,
    "Images":{},
    "Img":{},
    "Addimage":{},
    "Videos":{},
    "Video":{},
    "Addvideo":{},
    "laranganOn":False,
    "chat":False,
    "link":"https://i.gifer.com/7CJk.gif",
    "link":"https://www.smule.com",
    "mention":"Hati-Hati Kalau Ketemu Orang ini, Langsung Kabur Aja! ",
    "Respontag":"Jangan Suka Tag Teg Tog Kaka, Jewer Nih Kapok!!",
    "leave":"Terimakasih Kak Sudah Pernah Ada Di Room ini, Sampai Jumpa Lagi",
    "welcome":"Hallo Kak Selemat Datang, Salam Kenal Ya Kak, Semoga Betah Kak",
    "comment":"""
╭─「 Apk-Bots」─
│• 
│• Done Like & Comment
│• Add Owner kami
│• line.me/ti/p/~nspa_dede""",
    "message":"THANKS SUDAH ADD",
    "unsend":False,
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

comd = {
    "help": "help",
    "speed": "speed",
    "kick": "kick",
    "tagall": "hay",
    "cban": "cban",
    "siderOn": "sider on",
    "siderOff": "sider off",
    "bye": "@bye",
    "unsend": "unsend"
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

temptag = {
    "stealtag":False,
    "respontag":False,
}

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
with open('owner.json', 'r') as fp:
    owner = json.load(fp)
with open('sticker.json', 'r') as fp:
    stickers = json.load(fp)

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

stickersOpen = codecs.open("sticker.json","r","utf-8")
stickers = json.load(stickersOpen)

mulai = time.time()

def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return '%02d Jam %02d Menit %02d Detik' % (hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
    
def runtime2(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Menit %02d Detik' % (mins, secs)
   
def pretyPrintJson(djson):
        print(json.dumps(djson, indent=4, sort_keys=True))   

def allowLiff():
    url = 'https://access.line.me/dialog/api/permissions'
    data = {'on': ['P','CM'],'off': []}
    headers = {'X-Line-Access': cl.authToken,'X-Line-Application': cl.server.APP_NAME,'X-Line-ChannelId': '1602687308','Content-Type': 'application/json'}
    requests.post(url, json=data, headers=headers)

def sendFlexVideo(to, videoUrl, thumbnail='dark'):
    main = ["dark","red","cyan","yellow","green","white"]
    if thumbnail in main:
       thumbnail = f"https://i.ibb.co/njrRhyv/1643889938543.jpg"
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {'Content-Type': 'application/json','Authorization': 'Bearer %s' % token.accessToken}
    data = {'messages': [{'type': 'video','originalContentUrl': videoUrl,'previewImageUrl': thumbnail,}]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendFlexAudio(to, link):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {'Content-Type': 'application/json','Authorization': 'Bearer %s' % token.accessToken}
    data = {'messages': [{'type': 'audio','originalContentUrl': link,'duration': 250000}]}
    requests.post(url, headers=headers, data=json.dumps(data))


def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendCarousel(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendCarousel(to,col):
    col = json.dumps(col)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = cl.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=col, headers=headers)

def sendFoter(to, text):
    data = {"type": "text","text": text,"sentBy": {"label": "❑ ᴀᴘᴋ-ʙᴏᴛꜱ ❑","iconUrl": "https://i.ibb.co/TrcSqCX/ezgif-com-gif-maker-8.png","linkUrl": "line://nv/profilePopup/mid=u35aa06efe8cfc198633554199261cc60"}}
    sendTemplate(to, data)

def failOverAPI():
    try:
        result = requests.get("https://api.boteater.xyz",timeout=0.5)
        if result.status_code == 200:
            return "https://api.boteater.xyz"
        else:
            return "https://api.boteater.us"
    except:
        return "https://api.boteater.us"

def cytmp4(to,url):
    import pafy
    vid = pafy.new(url,basic=False)
    result = vid.streams[-1]
    return result.url
    links = cytmp4(anunya);links = 'https://'+cl.google_url_shorten(links)
    
def pendekin(to,url):
    req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
    payload = {'longUrl': url}
    headers = {'content-type': 'application/json'}
    r = requests.post(req_url, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    return resp['id']

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = cl.genOBSParams({'oid': mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "update profile failed"
        cl.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("vp.mp4")

def changeProfileVideo(to):
    if settings['changevp']['picture'] == None:
        return cl.sendReplyMessage(msg_id, to, "Foto tidak ditemukan")
    elif settings['changevp']['video'] == None:
        return cl.sendReplyMessage(msg_id, to, "Video tidak ditemukan")
    else:
        path = settings['changevp']['video']
        files = {'file': open(path, 'rb')}
        obs_params = cl.genOBSParams({'oid': cl.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = cl.server.postContent('{}/talk/vp/upload.nhn'.format(str(cl.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return cl.sendReplyMessage(msg_id, to, "Gagal update profile")
        path_p = settings['changevp']['picture']
        settings['changevp']['status'] = False
        cl.updateProfilePicture(path_p, 'vp')

def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = cl.getGroup(to)
        textx = "╭─「 Daftar anggota 」\n├↘\n├↘1. "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n├↘\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "├↘ {}. ".format(str(no))
            else:
                textx += "╰─「 Mentions {} Member 」".format(str(len(mid)))
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    cl.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getContact("u176ef6889643e290ba5801bffc83457b").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def khieMention(to, text="", mids=[]):
        arrData = ""
        arr = []
        mention = "@Mmk "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 5
                else:slen = len(textx);elen = len(textx) + 5
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def RhyN_(to, mid):
    try:
        aa = '{"S":"0","E":"5","M":'+json.dumps(mid)+'}'
        text_ = '@Khiez'
        cl.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)

def sendMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def mentionMembers2(to, mids=[]):
    if clMID in mids: mids.remove(clMID)
    parsed_len = len(mids)//20+1
    result = '╭───❑ Mention All ❑\n'
    mention = '@zeroxyuuki\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '│ %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '╰───❑ βŘҜ-Ŧ€ΔΜ-βØŦŞ ❑\n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            cl.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''

#message.createdTime -> 00:00:00
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")

def removeCmd(cmd, text):
	key = Setmain["keyCommand"]
	#if Setmain["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            print ("[25,26] SEND MESSAGE")
            return
        
        if op.type == 11 or op.type == 122:
            if op.param1 in protectqr:
                try:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            cl.reissueGroupTicket(op.param1)
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            cl.kickoutFromGroup(op.param1,[op.param2])
                except:
                    pass
                    
        if op.type == 13 or op.type == 124:
            if clMID in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                       cl.acceptGroupInvitation(op.param1)
                    else:
                       cl.acceptGroupInvitation(op.param1)                      

            if clMID in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        cl.acceptGroupInvitation(op.param1)
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)                      

        if op.type == 13 or op.type == 124:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    babi = op.param3.replace("",',')
                    memek = babi.split(",")
                    for sodok in memek:
                       cl.cancelGroupInvitation(op.param1,[sodok])
                       cl.kickoutFromGroup(op.param1,[op.param2])
                       wait["blacklist"] == True

        if op.type == 17 or op.type == 130:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                        	cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass

            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    X = cl.getGroup(op.param1)
                    X.preventedJoinByTicket = True
                    cl.updateGroup(X)
                    cl.kickoutFromGroup(op.param1,[op.param2])            
                        
                return

        if op.type == 0:
            return
        if op.type == 5:
              if wait["autoAdd"] == True:
                  cl.sendMessage(op.param1, wait["pesan"])          

        if op.type == 5:
            print ("[ 5 ] NOTIFIED AUTO BLOCK CONTACT")
            if wait["autoBlock"] == True:
                cl.blockContact(op.param1)
                cl.sendMessage(op.param1, "Sorry Auto Block Is Active, Please Comment In Time Line For Unblock Contact tq..")

        if op.type == 19 or op.type == 133:     
            if op.param1 in protectkick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    cl.kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

        if op.type == 32 or op.type == 126:                 
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            cl.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
                        
                return

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

            if op.param1 in Setmain["RAreadPoint"]:
                if op.param2 in Setmain["RAreadMember"][op.param1]:
                    pass
                else:
                    Setmain["RAreadMember"][op.param1][op.param2] = True
            else:
                pass

        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        contact = cl.getContact(op.param2)
                        tz = pytz.timezone("Asia/Jakarta")
                        cover = cl.getProfileCoverURL(op.param2)
                        timeNow = datetime.now(tz=tz)
                        cl.sendMessage(op.param1, wait["mention"])                 
			
        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              cl.kickoutFromGroup(msg.to, [msg._from])
                          except:
                              cl.kickoutFromGroup(msg.to, [msg._from])
   
        if op.type == 25 or op.type == 26:
            try:
                print ("[ 25 ] SEND MESSAGE")
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                to = msg.to
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != cl.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if msg.contentType == 0:
                        if text is None:
                            return

            except:
                pass

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            stickername = str(text)
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver         
               if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                 if wait["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention["M"] in clMID:
                           contact = cl.getContact(msg._from)
                           anu = contact.displayName
                           cl.sendReplyMessage(msg.to,id, anu)
                           sid = str(wait["AddstickerTag"]["sid"])
                           spkg = str(wait["AddstickerTag"]["spkg"])
                           cl.sendSticker(msg.to, spkg, sid)
                           break
                                                                                                    
               if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in clMID:
                           cl.sendReplyMessage(msg.id,to, "Sorry Notag Active!!")
                           cl.kickoutFromGroup(msg.to, [msg._from])
                           break

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            stickername = str(text)
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
#ADD Bots
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        c.sendMessage(msg.to,"Sudah dalam daftar bot\nSilahkan ketik refresh")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        c.sendMessage(msg.to,"Masuk dalam daftar bots\nSilahkan ketik refresh")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        c.sendMessage(msg.to,"Berhasil menghapus dari anggota bot\nSilahkan ketik refresh")
                    else:
                        wait["dellbots"] = True
                        c.sendMessage(msg.to,"Contact itu bukan anggota bot\nSilahkan ketik refresh")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        c.sendMessage(msg.to,"Contact itu sudah jadi staff\nSilahkan ketik refresh")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        c.sendMessage(msg.to,"Berhasil menambahkan ke staff\nSilahkan ketik refresh")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        c.sendMessage(msg.to,"Berhasil menghapus dari staff\nSilahkan ketik refresh")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        c.sendMessage(msg.to,"Contact itu bukan staff\nSilahkan ketik refresh")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        c.sendMessage(msg.to,"Contact itu sudah jadi admin\nSilahkan ketik refresh")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        c.sendMessage(msg.to,"Berhasil menambahkan ke admin\nSilahkan ketik refresh")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        c.sendMessage(msg.to,"Berhasil menghapus dari admin\nSilahkan ketik refresh")
                    else:
                        wait["delladmin"] = True
                        c.sendMessage(msg.to,"Contact itu bukan admin\nSilahkan ketik refresh")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        c.sendMessage(msg.to,"Contact itu sudah ada di blacklist\nSilahkan ketik refresh")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        c.sendMessage(msg.to,"Masuk daftar blacklist\nSilahkan ketik refresh")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        c.sendMessage(msg.to,"Unbaned blacklist\nSilahkan ketik refresh")
                    else:
                        wait["dblacklist"] = True
                        c.sendMessage(msg.to,"Contact itu tidak ada di blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        c.sendMessage(msg.to,"Contact itu sudah ada di Talkban\nSilahkan ketik refresh")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        c.sendMessage(msg.to,"Berhasil menambahkan ke Talkban user\nSilahkan ketik refresh")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        c.sendMessage(msg.to,"Berhasil menghapus dari Talkban user\nSilahkan ketik refresh")
                    else:
                        wait["Talkdblacklist"] = True
                        c.sendMessage(msg.to,"Contact itu tidak ada di Talkban\nSilahkan ketik refresh")
#UPDATE FOTO
               if msg.contentType == 1:
      #         if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     c.sendMessage(msg.to, "Success")
               if msg.contentType == 1:
                   if msg._from in admin:
                       if clMID in wait["changeFoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del wait["changeFoto"][clMID]
                            cl.updateProfilePicture(path)
                            c.sendMessage(msg.to,"Foto berhasil dirubah")
                   if msg._from in admin:
                       if clMID in settings["changeCover"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del settings["changeCover"][clMID]
                            cl.updateProfileCover(path)
                            c.sendMessage(to, "Updated")                                                            

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                    for cmd in cmd.split(","):
                        if cmd == "chatbot on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                ret = "Chatbot Enable."
                                c.sendMessage(msg.to, str(ret))

                        elif cmd == "!help":
                          if msg._from in admin:
                            vian = "╭─────────────\n"
                            vian += "├──≽ JAVA SCRIPT\n"
                            vian += "├≽ !nuke: numb\n"
                            vian += "├≽ !bantai: numb\n"
                            vian += "├≽ !boom\n"
                            vian += "├≽ !mayhem\n"
                            vian += "├≽ !fuck @\n"
                            vian += "├≽ !test name\n"
                            vian += "├──≽ GROUPS\n"
                            vian += "├≽ !glist\n"
                            vian += "├≽ !bye\n"
                            vian += "├≽ !bye: numb\n"
                            vian += "├≽ !left: name grup\n"
                            vian += "├≽ !kick @\n"
                            vian += "├≽ !adminadd @\n"
                            vian += "├≽ !admindell @\n"
                            vian += "├≽ !admin:add\n"
                            vian += "├≽ !admin:dell\n"
                            vian += "├≽ !admin:off\n"
                            vian += "├≽ !autojoin on/off\n"
                            vian += "│ • ❑ βŘҜ-Ŧ€ΔΜ-βØŦŞ ❑\n"
                            vian += "╰─────────────\n"
                            cl.sendReplyMessage(msg.id,to, str(vian))
                              
                        elif cmd == "!chatbot off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                cl.sendReplyMessage(msg.id,to, "Chatbot disable.")
                        elif cmd == "!chatbot on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                cl.sendReplyMessage(msg.id,to, "Chatbot enable.")

                        elif cmd == "!clear":
                            if msg._from in admin:
                                #process = os.popen('cd /tmp/ && rm -r *')
                                process = os.popen('sync; echo 1 > /proc/sys/vm/drop_caches')
                                a = process.read()
                                cl.sendReplyMessage(msg.id,to, "Cleared server.")
                                
                        elif cmd == "!cancelall":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                    group = cl.getGroup(to)
                                    if group.invitee is None or group.invitee == []:
                                        cl.sendReplyMessage(msg.id,to, "Nothing")
                                    else:
                                        invitee = [contact.mid for contact in group.invitee]
                                        for inv in invitee:
                                            cl.cancelGroupInvitation(to, [inv])
                                        cl.sendReplyMessage(msg.id,to, "Cancelled {} Group Pending".format(str(len(invitee))))
                                
                        elif cmd == "!accept:all":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                    group = cl.getGroup(to)
                                    if group.invitee is None or group.invitee == []:
                                        cl.sendMessage(to, "No Have Groups Invitation.")
                                    else:
                                        invitee = [contact.mid for contact in group.invitee]
                                        for acc in invitee:
                                            cl.acceptGroupInvitation(to, [acc])
                                        cl.sendMessage(to, "Join {} Groups".format(str(len(invitee))))
                              
                        elif text.lower() == "!clearchat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                                   cl.sendMessage(msg.to, "Cleared messages")
                               except:
                                   pass
                                
                        elif cmd == "!reboot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "Waitting 1 second")
                               time.sleep(5)
                               Setmain["restartPoint"] = msg.to
                               cl.sendMessage(msg.to, "Be reboot to pee.")
                               restartBot()
                                                          
                        elif cmd == "!runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                eltime = time.time() - mulai
                                bot = runtime(eltime)
                                cl.sendMessage(msg.to, bot)

                        elif cmd == "!friendlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "┃┃ " + str(a) + ". " +G.displayName+ "\n"
                               cl.sendMessage(msg.id,to,"┏━━[ FRIEND LIST ]\n┃┃\n"+ma+"┃┃\n┗━━[ Total「"+str(len(gid))+"」Friends ]")
                               
                        elif cmd.startswith("!bye:"):
                            if wait["selfbot"] == True:
                              if msg._from in admin:
                                  separate = cmd.split(":")
                                  number = cmd.replace(separate[0] + ":","")
                                  groups = cl.getGroupIdsJoined()
                                  try:
                                      group = groups[int(number)-1]
                                      G = cl.getGroup(group)
                                      try:
                                          cl.leaveGroup(G.id)
                                      except:
                                          cl.leaveGroup(G.id)
                                      cl.sendMessage(msg.to, "Leave Group : " + G.name)
                                  except Exception as error:
                                      cl.sendMessage(msg.to, str(error))

                        elif cmd == "!gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "!oqr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                   cl.sendMessage(msg.to, "Open Link Groups")

                        elif cmd == "!cqr":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   cl.sendMessage(msg.to, "Blocked Url Groups")

                        elif cmd == "!url":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = cl.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      cl.updateGroup(x)
                                   gurl = cl.reissueGroupTicket(msg.to)
                                   cl.sendMessage(msg.to, "Nama : "+str(x.name)+ "\nUrl : http://line.me/R/ti/g/"+gurl)
                                                        
                        elif cmd.startswith("!uns "):
                            if msg._from in admin:
                                sep = text.split(" ")
                                args = text.replace(sep[0] + " ", "")
                                mes = 0
                                try:
                                    mes = int(args[1])
                                except:
                                    mes = 1
                                M = cl.getRecentMessagesV2(to, 101)
                                MId = []
                                for ind, i in enumerate(M):
                                    if ind == 0:
                                        pass
                                    else:
                                        if i._from == cl.profile.mid:
                                            MId.append(i.id)
                                            if len(MId) == mes:
                                                break
                                def unsMes(id):
                                    cl.unsendMessage(id)
                                for i in MId:
                                    thread1 = threading.Thread(target=unsMes, args=(i,))
                                    thread1.start()
                                    thread1.join()
                                cl.unsendMessage(msg.id)
   
                        elif cmd == "!tag":
                          if msg._from in admin:
                            cl.unsendMessage(msg.id)
                            members = []
                            if msg.toType == 1:
                                room = cl.getCompactRoom(to)
                                members = [mem.mid for mem in room.contacts]
                            elif msg.toType == 2:
                                group = cl.getCompactGroup(to)
                                members = [mem.mid for mem in group.members]
                            else:
                                return cl.sendMessage(to, 'Failed mentionall members, use this command only on room or group chat')
                            if members:
                                mentionMembers2(to, members)                              
#===========BOT UPDATE============#
                        elif cmd == "!uppictgrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                cl.sendMessage(msg.to,"Send a Picture ♪")
                                
                        elif cmd == "!upcover":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changeCover"][clMID] = True
                                cl.sendMessage(msg.to,"Send a Picture ♪")

                        elif cmd == "!uppict":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["changeFoto"][clMID] = True
                                c.sendMessage(msg.to,"Send a Picture ♪")
                               
                                
                        elif cmd.startswith("!upcname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.id,to,"Update to " + string + "")
#=========================================================#                                                     
                        elif cmd == "!bye":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                cl.sendMessage(msg.to, "Sayonara......")
                                cl.leaveGroup(msg.to)

                        elif cmd == "!speed":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                start = time.time()
                                cl.sendMessage("u0a94a68c058d99a72f95b420a0b7a493", "test speed")
                                speed = time.time() - start
                                ping = speed * 1000
                                cl.sendReplyMessage(msg.id,to, "Time {} Ms !".format(str(speedtest(ping))))
                                                                                 
                        elif cmd.startswith("!upgname"):
                          if msg._from in admin:
                            if msg.toType == 2:
                                X = cl.getGroup(to)
                                X.name = text.split(" ")
                                cl.updateGroup(X)                                                              
                                
                        elif cmd.startswith("!addfriend "):
                          if msg._from in admin:  
                            if msg.contentMetadata is not None  and 'MENTION' in msg.contentMetadata:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = cl.getContact(ls)
                                    cl.findAndAddContactsByMid(ls)
                                cl.sendMessage(msg.to, "Success Add " + str(contact.displayName) + " to Friendlist")
      
                        elif cmd.startswith("!invite "):
                                if msg._from in creator or msg._from in owner or msg._from in admin:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key["MENTIONEES"][0]["M"]
                                    targets = []
                                    for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                    for target in targets:                                                                            
                                        try:      
                                            cl.findAndAddContactsByMid(target)
                                            cl.inviteIntoGroup(to,[target])                                             
                                        except:
                                            pass
#===========KICKOUT============#

                        elif cmd.startswith("!kick "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           cl.kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

#===========ADMIN ADD============#
                        elif cmd.startswith("!adminadd "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           cl.sendMessage(msg.to,"Add To Adminlist ✓")
                                       except:
                                           pass

                        elif cmd.startswith("!admindell "):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Alvian:
                                       try:
                                           admin.remove(target)
                                           cl.sendMessage(msg.to,"Delete Admin ✓")
                                       except:
                                           pass
                                           
                        elif cmd == "!admin:add":
                            if msg._from in admin:
                                wait["addadmin"] = True
                                cl.sendMessage(msg.to,"Send Contact ✓")

                        elif cmd == "admin:dell":
                            if msg._from in admin:
                                wait["delladmin"] = True
                                cl.sendMessage(msg.to,"Send Contact ✓")

                        elif cmd == "!admin:off" or cmd == "abort":
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                cl.sendMessage(msg.to,"Command addmin aborted")
#===========COMMAND ON OFF============#                        
                        elif cmd == "!autoread on":
                            if msg._from in admin:
                                Setmain["autoRead"] = True
                                cl.sendMessage(msg.to, "Auto Read Enable ✓")                            
                        elif cmd == "!autoread off":
                            if msg._from in admin:
                                Setmain["autoRead"] = False
                                cl.sendMessage(msg.to, "Auto Read Disable ✓")

                        elif cmd == "!autoblock on":
                            if msg._from in admin:
                                wait["autoBlock"] = True
                                cl.sendMessage(msg.to, "Auto Block Enable")
                            
                        elif cmd == "!autoblock off":
                            if msg._from in admin:
                                wait["autoBlock"] = False
                                cl.sendMessage(msg.to, "Auto Block Disable")

                        elif cmd == "!autojoin on":
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                cl.sendMessage(msg.to, "Auto Join Enable.")                          
                        elif cmd == "!autojoin off":
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                cl.sendMessage(msg.to, "Auto Join Disable")
       
                        elif cmd == "!cban":
                          if wait["selfbot"] == True:  
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                   ret = "Blacklist Empty"
                                   cl.sendMessage(msg.to, str(ret))
                              else:
                                   ret = "Cleared {} Blacklist".format(str(len(wait["blacklist"])))
                                   cl.sendMessage(msg.to, str(ret))
                                   wait["blacklist"] = {}
                                                       
#===========COMMAND BLACKLIST============#
                        elif cmd == "!banlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                flexvian(msg.to,"No Body Is Banned")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"↘Blacklist User↘\n\n"+ma+"\n↘Total「%s」Blacklist User↘" %(str(len(wait["blacklist"]))))

                        elif cmd.startswith("!lefft: "):
                            if msg._from in admin:
                                proses = text.split(" ")
                                ng = text.replace(proses[0] + " ","")
                                gid = cl.getGroupIdsJoined()
                                for i in gid:
                                    h = cl.getGroup(i).name
                                    if h == ng:
                                        cl.sendMessage(i, "Waitting for notifed success")
                                        cl.leaveGroup(i)
                                        cl.sendMessage(to,"Leave all group " +h)

                        elif msg.text.startswith("!fuck "):
                        	if msg._from in owner or msg._from in admin:                       
                                        nk0 = msg.text.replace("!fuck ","")
                                        nk1 = nk0.lstrip()
                                        nk2 = nk1.replace("@","")
                                        nk3 = nk2.rstrip()
                                        _name = nk3
                                        gs = cl.getGroup(msg.to)
                                        targets = []
                                        for s in gs.members:
                                            if _name in s.displayName:
                                                targets.append(s.mid)
                                        if targets == []:
                                          cl.sendMessage(msg.to,"target not found")
                                        lolz = 'simple.js gid={} token={} app={}'.format(to, cl.authToken, "DESKTOPMAC\t11.2.5\tMac_Os\t11.2.5")
                                        for target in targets:
                                            lolz += ' uid={}'.format(target)
                                        success = execute_js(lolz)

                        elif "!test " in msg.text:
                            if msg._from in admin:
                                pisah = text.split("!test ")
                                nk0 = text.replace(pisah[0]+"!test ","")
                                nk1 = nk0.lstrip()
                                _name = nk1
                                gs = cl.getGroup(msg.to)
                                targets = []
                                for i in gs.members:
                                    if _name in i.displayName:
                                        targets.append(i.mid)
                                if targets == []:
                                  cl.sendMessage(msg.to,"target not found")
                                lolz = 'simple.js gid={} token={} app={}'.format(to, cl.authToken, "DESKTOPMAC\t11.2.5\tMac_Os\t11.2.5")
                                for target in targets:
                                    lolz += ' uid={}'.format(target)
                                success = execute_js(lolz)

                        elif cmd == "!mayhem":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                cl.unsendMessage(msg.id)
                                xyz = cl.getGroup(to)
                                mem = [c.mid for c in xyz.members]
                                targets = []
                                for x in mem:
                                  if x not in admin:targets.append(x)
                                if targets:
                                  lolz = 'simple.js gid={} token={} app={}'.format(to, cl.authToken)
                                  for target in targets:
                                    lolz += ' uid={}'.format(target)
                                  success = execute_js(lolz)
                                  if success:cl.sendMessage(to, "Cleanse %i members." % len(targets))
                                  else:cl.sendMessage(to, "Failed kick %i members." % len(targets))
                                else:cl.sendMessage(to, "Target not found.")

                        elif cmd.startswith("!nuke:"):
                            if wait["selfbot"] == True:
                              if msg._from in admin:
                                  separate = cmd.split(":")
                                  number = cmd.replace(separate[0] + ":","")
                                  groups = cl.getGroupIdsJoined()
                                  try:
                                      group = groups[int(number)-1]
                                      xyz = cl.getGroup(group)
                                      try:
                                          mem = [c.mid for c in xyz.members]
                                          targets = []
                                          for x in mem:
                                              if x not in admin:targets.append(x)
                                          if targets:
                                              lolz = 'simple.js gid={} token={} app={}'.format(to, cl.authToken)
                                              for target in targets:
                                                  lolz += ' uid={}'.format(target)
                                              execute_js(lolz)
                                      except:
                                          mem = [c.mid for c in xyz.members]
                                          targets = []
                                          for x in mem:
                                              if x not in admin:targets.append(x)
                                          if targets:
                                              lolz = 'simple.js gid={} token={} app={}'.format(to, cl.authToken)
                                              for target in targets:
                                                  lolz += ' uid={}'.format(target)
                                              execute_js(lolz)
                                      cl.sendMessage(msg.to, "Nuke : " + xyz.name)
                                  except Exception as error:
                                      cl.sendMessage(msg.to, str(error))

                        elif cmd.startswith("!bantai: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                separate = msg.text.split(":")
                                number = msg.text.replace(separate[0] + ":"," ")
                                groups = cl.getGroupIdsJoined()
                                gid = groups[int(number)-1]                             
                                xyz = cl.getGroup(gid)
                                if xyz.invitee == None:pends = []
                                else:pends = [c.mid for c in xyz.invitee]
                                targp = []
                                for x in pends:
                                  if x not in admin:targp.append(x)
                                mems = [c.mid for c in xyz.members]
                                targk = []
                                for x in mems:
                                  if x not in admin:targk.append(x)
                                lolz = 'dual.js gid={} token={}'.format(gid, cl.authToken)
                                for x in targp:lolz += ' uid={}'.format(x)
                                for x in targk:lolz += ' uik={}'.format(x)
                                success = execute_js(lolz)
                                if success:
                                    x = cl.getGroup(msg.to)
                                    if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      cl.updateGroup(x)
                                      gurl = cl.reissueGroupTicket(msg.to)
                                    cl.sendMessage(msg.to, "Nama : "+str(x.name)+ "\nUrl : http://line.me/R/ti/g/"+gurl)

                        elif cmd == "!boom":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                cl.unsendMessage(msg.id)
                                xyz = cl.getGroup(to)
                                if xyz.invitee == None:pends = []
                                else:pends = [c.mid for c in xyz.invitee]
                                targp = []
                                for x in pends:
                                  if x not in admin:targp.append(x)
                                mems = [c.mid for c in xyz.members]
                                targk = []
                                for x in mems:
                                  if x not in admin:targk.append(x)
                                lolz = 'dual.js gid={} token={}'.format(to, cl.authToken)
                                for x in targp:lolz += ' uid={}'.format(x)
                                for x in targk:lolz += ' uik={}'.format(x)
                                execute_js(lolz)

    except Exception as error:
        print (error)


while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                avs = threading.Thread(target=bot(op))
                avs.start()
                avs.join()
                oepoll.setRevision(op.revision)
    except Exception as e:
        pass
